package org.iucn.sis.server.api.persistance.ormmapping;

public class ClassLoaderTester {

}
