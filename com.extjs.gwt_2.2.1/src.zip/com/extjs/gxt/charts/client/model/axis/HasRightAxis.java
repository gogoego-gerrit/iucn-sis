/*
 * Ext GWT 2.2.1 - Ext for GWT
 * Copyright(c) 2007-2010, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */
package com.extjs.gxt.charts.client.model.axis;

public interface HasRightAxis {
  boolean isRightAxis();
  
  void setRightAxis(boolean rightAxis);
}
